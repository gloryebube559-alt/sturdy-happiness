# EbubeCode — Learn to Code, Build Your Future

EbubeCode is a beginner-friendly coding practice website with:
- Beginner lessons covering HTML, CSS and JavaScript
- Short quizzes with instant feedback and points
- Coding challenges with sample solutions
- A JavaScript practice editor with a console output panel
- Progress saved locally in the browser
- Responsive mobile layout and basic installable-app support (PWA)

## Run it locally
1. Download and extract this ZIP.
2. Open `index.html` in a modern browser.
3. For install/offline features, use a static web server or publish the files to GitHub Pages.

## Publish on GitHub Pages
1. Open your repository on GitHub.
2. Choose **Add file → Upload files**.
3. Upload the contents of this folder (not the outer ZIP). Keep `index.html` in the repository root.
4. Commit the changes to the `main` branch.
5. Go to **Settings → Pages**.
6. Under **Build and deployment**, select **Deploy from a branch**.
7. Choose branch `main` and folder `/(root)`, then press **Save**.
8. Wait for the Pages deployment, then open the URL shown in Settings → Pages.

Your likely URL format is `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

## Notes
- This is a front-end starter app. Progress is stored on the current browser/device using localStorage and does not sync between devices.
- The editor runs JavaScript in the page context. Only run code you understand. It is a learning playground, not a secure sandbox for untrusted code.
- This version does not include accounts, cloud sync, a backend, or a native Android APK.
- `manifest.json` and `sw.js` provide basic PWA support when served over HTTPS. Depending on the Android browser, you may be able to use **Add to Home screen** / **Install app**.

## License
MIT — see `LICENSE`.
